var btn = document.querySelector('#show-or-hide');
var dialog = document.querySelector('.dialog');

btn.addEventListener('click', function(){
    if (dialog.style.display === 'block') {
        dialog.style.display === 'none';
    }else {
        dialog.style.display === 'block';
    }
});